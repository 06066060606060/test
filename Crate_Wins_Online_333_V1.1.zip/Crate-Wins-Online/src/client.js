//030317

var Client = {};
Client.socket = io.connect();


Client.ask_new_player = function()
{
    Client.socket.emit('newplayer');
};

//Send socket id to server, adding new p on server then
Client.send_socket_id_to_server = function(id)
{
    console.log("socket id sent to server");
    Client.socket.emit('player_socket_id_transmission',{id:id});
};

Client.refresh_server = function(id)
{
    Client.socket.emit('refresh_server');
};

Client.send_click = function(row,column,pid)
{
  Client.socket.emit('click',{row:row,column:column,pid:pid});
};

Client.socket.on('receive_click',function(data)
{
    console.log('Row: '+data.row+', Column: '+data.column + '  (pid: ' + data.pid + ')');
    GameplayScene.receive_message_move(data.row, data.column, data.pid);
});

Client.socket.on('newplayer',function(data)
{
    //GameplayScene.addNewPlayer(data.id);
});

Client.socket.on('ready_to_start', function(starting_player)
{
   //GameplayScene.ready_start(starting_player); 
});

Client.socket.on('allplayers',function(data)
{
    for(var i = 0; i < data.length; i++){
        //GameplayScene.addNewPlayer(data[i].id);
        //GameplayScene.addNewPlayer(data[i].id);
    }

    Client.socket.on('move',function(data){
        console.log('Dice: '+data.x+', Pawn index: '+data.y+'  (pid: ' + data.id + ')');
    });

    Client.socket.on('remove',function(id){
        //Game.removePlayer(id);
    });
});


