class GameplayScene extends Phaser.Scene  //wwwclass
{
    
    //socket
    //
        playing_player_socket_id;
        static this_instance;
    //
    
    grid;
    crates = [];

    object_pooler;

    points_acquired_in_session = 0;

    smoke_effects = [];

    timer_make_new_grid = 555;
    TMNG_START_VAL = 1.5 * 60;

    panel_active_ind = 555;
    panels = [];

    side_menu;

    points_text;
    moves_text;

    sounds_enabled = true;

    //Loop vars
        i; j;

    constructor()
    {
        super('GS');
        GameplayScene.this_instance = this;
    }

    create()
    {   
        this.object_pooler = new ObjectPooling(this);
        this.grid = new Grid(this);

        this.points_text = this.add.text(50, 612, "Session Points:", { fontFamily: 'Arial', fontSize: '22px', fill: '#FFFFFF' });
        this.moves_text = this.add.text(300, 612, "Moves available: " + UserData.free_clicks, { fontFamily: 'Arial', fontSize: '22px', fill: '#FFFFFF' });
        this.stars_text = this.add.text(606, 612, "Stars: " + UserData.stars, {fontFamily: 'Arial', fontSize: '22px', fill: '#FFFFFF'});
        
        this.side_menu = new SideMenu(this);
        
        this.panels.push(new WelcomePanel(this));
        this.panels.push(new WinListPanel(this));
        this.panels.push(new InstructionsPanel(this));
        this.panels[0].init();
    }

    static receive_message_move(row, column, pid) //grid id also
    {
        if (pid != GameplayScene.this_instance.playing_player_socket_id)
        {
            GameplayScene.this_instance.grid.crates[row * GameplayScene.this_instance.grid.GRID_SIZE[0]
                                                   + column].clicked(false);
        }
    }
    
    socket_id_init()
    {
        //Socket ID getting + Transmision
        //
            if (this.playing_player_socket_id == null)
            {
                console.log("This socket id: " + this.game.socket.id);
                if (this.game.socket.id != null)
                {
                    this.playing_player_socket_id = this.game.socket.id;
                    console.log("Sending socket id to server");
                    Client.send_socket_id_to_server(this.game.socket.id);
                }
            }
        //
    }
    
    update()
    {  
        this.socket_id_init();
        for (this.i = 0; this.i < this.smoke_effects.length; this.i++)
        {
            this.smoke_effects[this.i].update();
        }
        for (this.i = 0; this.i < this.panels.length; this.i++)
        {
            if (this.panels[this.i].visible)
            {
                this.panels[this.i].update();
            }
        }
        this.side_menu.update();
        this.grid.update();
        this.make_new_grid_timer_update();
    }

    make_new_grid_timer_update()
    {
        if (this.timer_make_new_grid != 555)
        {
            if (this.timer_make_new_grid > 0)
            {
                this.timer_make_new_grid--;
            }
            else
            {
                this.timer_make_new_grid = 555;
                this.grid.generate_grid_data();
                this.grid.generate_crates();
            }
        }
    }

    check_if_moves_available()
    {
        var return_val = false;
        if (this.panel_active_ind == 555 && this.timer_make_new_grid == 555)
        {
            if (UserData.free_clicks > 0)
            {
                UserData.change_free_clicks(-1);
                this.refresh_clicks_text();
                return_val = true;
            }
            else
            {
                this.add_panel(0);
            }
        }
        return return_val;
    }

    highest_val_fruit_uncovered()
    {
        this.timer_make_new_grid = this.TMNG_START_VAL;
    }

    score_increase(inc)
    {
        this.points_acquired_in_session += inc;
        this.points_text.text = "Session Points: " + this.points_acquired_in_session;
    }

    refresh_clicks_text()
    {
        this.moves_text.text = "Moves available: " + UserData.free_clicks;
    }

    refresh_stars_text()
    {
        this.stars_text.text = "Stars: " + UserData.stars;
    }

    add_panel(ind)
    {
        if (this.panel_active_ind != 555)
        {
            this.panels[this.panel_active_ind].hide_panel_init(true);
        }
        this.panels[ind].init();
    }

    play_sound(snd)
    {
        if (this.sounds_enabled)
        {
            this.sound.play(snd);
        }
    }

    make_new_smoke_effect(x, y)
    {
        var se = this.object_pooler.get_a_smoke_effect(x,y);
        se.init();
        this.smoke_effects.push(se);
        //console.log(this.smoke_effects);
        //console.log(this.object_pooler.smoke_effects_pool);
    }

}
