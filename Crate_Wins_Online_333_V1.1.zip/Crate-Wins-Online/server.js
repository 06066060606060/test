var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io').listen(server);

app.use('/css',express.static(__dirname + '/css'));
app.use('/src',express.static(__dirname + '/src'));
app.use('/assets',express.static(__dirname + '/assets'));

app.get('/',function(req,res)
{
    res.sendFile(__dirname+'/index.html');
});

server.lastPlayerID = 0;
server.players = [];

var port = process.env.PORT || 8081;

server.listen(port, () => 
{
    console.log(`Crate Wins Server listening on ${port}`);
});


io.on('connection',function(socket)
{

    socket.on('newplayer',function()
    {
        socket.player = 
        {
            id: server.lastPlayerID++
        };
        socket.emit('allplayers', get_all_players());
        socket.broadcast.emit('newplayer',socket.player);

        socket.on('click',function(data)
        {
            io.emit('receive_click',data);
        });

        socket.on('disconnect',function()
        {
            io.emit('remove',socket.player.id);
        });
    });

    socket.on('player_socket_id_transmission',function(data)
    {
        console.log('Player socket id transmission activate on server: ' + data.id);
        server.players.push(data.id);
        console.log("Server players:" + server.players.length);
        console.log("Check start...");
    });
    
    socket.on('refresh_server',function()
    {
        console.log("Refreshing server data");
        server.players = [];
        server.lastPlayerID = 0;
    });
    
});

function get_all_players()
{
    var players = [];
    Object.keys(io.sockets.connected).forEach(function(socketID){
        var player = io.sockets.connected[socketID].player;
        if(player) players.push(player);
    });
    return players;
}

function randomInt (low, high) {
    return Math.floor(Math.random() * (high - low) + low);
}
