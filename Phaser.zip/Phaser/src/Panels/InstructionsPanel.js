class InstructionsPanel extends Panel
{

    constructor (scene)
    {
        super(scene, 'InstructionsPanel');
        this.has_a_close_button = true; //just putting this to true automatically gives Panel a close button
    }
    
}