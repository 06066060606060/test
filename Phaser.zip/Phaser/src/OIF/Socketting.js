class Socketting
{

    static socket;
    
    static init_socket()
    {
        Socketting.socket = io.connect();
        //Events
        //

            //It should trigger after a click is sent, for all players
            Socketting.socket.on('receive_click', 
                function(data)
                {
                    console.log('Row: ' + data.row + ', Column: ' + data.column 
                                + '  (pid: ' + data.pid + ', gid id: ' + data.gid + ')');
                    GameplayScene.receive_message_move(data.row, data.column, data.pid, data.gid);
                });

        //
    }
    
    static ask_new_player()
    {
        console.log("Started up Phaser project. New player event emit");
        //Emit new player event to trigger on_new_player_event
        //Socketting.socket.emit('newplayer');
    }

    //Send socket id to server, adding new p on server then
    //Socket id is used to check if click received is from another player
    static send_socket_id_to_server(id)
    {
        console.log("socket id sent to server: " + id);
        Socketting.socket.emit('player_socket_id_transmission',{id:id});
    }

    static refresh_server(id)
    {
        Socketting.socket.emit('refresh_server');
    }

    static send_click(row,column, pid,gid)
    {
        //Emit for trigerring on_receive_click_event:
        Socketting.socket.emit('click',{row:row,column:column,pid:pid,gid:gid});
    }
    
}
