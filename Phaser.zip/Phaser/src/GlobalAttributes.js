class GlobalAttributes
{

    static SPINS_WON_FOR_1_STAR = 15;
    
}
